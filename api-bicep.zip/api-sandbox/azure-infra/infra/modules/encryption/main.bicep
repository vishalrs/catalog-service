targetScope = 'resourceGroup'

@description('Name of the existing Key Vault')
param keyVaultName string

@description('Resource ID of the existing Key Vault')
param keyVaultId string

@description('Name of the key to create in the Key Vault')
param keyName string

@description('Name of the Disk Encryption Set')
param diskEncryptionSetName string

@description('Azure region for the Disk Encryption Set')
param location string

@description('Encryption type for the Disk Encryption Set')
param diskEncryptionSetEncryptionType string

@description('Role definition ID used for Key Vault RBAC assignment')
param keyVaultRbacRoleDefinitionId string

@description('Scope type for Key Vault RBAC assignment')
param keyVaultRbacScopeType string

@description('Target resource group name for Key Vault RBAC assignment')
param keyVaultRbacTargetResourceGroupName string

@description('Suffix used to generate Key Vault RBAC role assignment name')
param keyVaultRbacRoleAssignmentNameSuffix string

resource existingKeyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyVaultName
}

resource existingKeyVaultKey 'Microsoft.KeyVault/vaults/keys@2023-07-01' existing = {
  parent: existingKeyVault
  name: keyName
}

var keyUriWithVersion = existingKeyVaultKey.properties.keyUriWithVersion

resource diskEncryptionSet 'Microsoft.Compute/diskEncryptionSets@2024-03-02' = {
  name: diskEncryptionSetName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    encryptionType: diskEncryptionSetEncryptionType
    activeKey: {
      sourceVault: {
        id: keyVaultId
      }
      keyUrl: keyUriWithVersion
    }
  }
}

module keyVaultRbac './../keyvault-rbac/main.bicep' = {
  name: 'keyvault-rbac-${diskEncryptionSetName}'
  params: {
    principalId: diskEncryptionSet.identity.principalId
    roleDefinitionId: keyVaultRbacRoleDefinitionId
    scopeType: keyVaultRbacScopeType
    targetResourceGroupName: keyVaultRbacTargetResourceGroupName
    targetResourceName: keyVaultName
    roleAssignmentNameSuffix: keyVaultRbacRoleAssignmentNameSuffix
  }
}

output keyName string = keyName
output keyUriWithVersion string = keyUriWithVersion
output diskEncryptionSetName string = diskEncryptionSet.name
output diskEncryptionSetId string = diskEncryptionSet.id
output diskEncryptionSetPrincipalId string = diskEncryptionSet.identity.principalId
