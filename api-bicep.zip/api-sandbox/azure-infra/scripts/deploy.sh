#!/usr/bin/env bash
set -euo pipefail

environment="${1:-dev}"
location="${2:-eastus}"

az deployment sub create \
  --location "$location" \
  --template-file azure-infra/infra/main.bicep \
  --parameters environmentName="$environment"
