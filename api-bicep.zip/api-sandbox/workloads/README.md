# Workload Deployment

Use this folder for Kubernetes workload deployment assets (pods, apps, services, and related rollout automation).

## Structure

- `manifests/`: Kubernetes manifests such as namespaces, service accounts, deployments, services, and other cluster resources.
- `environments/`: Environment-specific `variables.yml` files used by workload pipelines, such as namespace names, AKS cluster names, and managed identity client IDs.
- `pipelines/`: CI/CD pipeline YAML files for workload deployments.
- `scripts/`: Shell scripts used by those pipelines (kubectl/helm wrappers, validation, rollout checks).

## Suggested naming

- Pipelines: `deploy-<app>-<env>.yml`
- Scripts: `deploy-<app>.sh`, `validate-<app>.sh`, `rollback-<app>.sh`

## Notes

- Manifest files can be stored as reusable templates with placeholder tokens and rendered in pipeline runs with environment-specific values such as namespace names, service account names, and managed identity client IDs.
