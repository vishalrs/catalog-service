using '../../solution.bicep'

param environmentName = 'dev'
param networkConfig = {
  resourceGroupName: 'asbx-dev-rg-01'
  vnetName: 'asbx-dev-vnet-01'
  networkSecurityGroupName: 'asbx-dev-nsg-01'
  aksNetworkSecurityGroupName: 'asbx-dev-nsg-aks-01'
  privateEndpointsNetworkSecurityGroupName: 'asbx-dev-nsg-pe-01'
  applicationGatewayNetworkSecurityGroupName: 'asbx-dev-nsg-agw-01'
  managementNetworkSecurityGroupName: 'asbx-dev-nsg-mgmt-01'
  aksSubnetName: 'asbx-dev-snet-aks-01'
  privateEndpointsSubnetName: 'asbx-dev-snet-pe-01'
  applicationGatewaySubnetName: 'asbx-dev-snet-agw-01'
  managementSubnetName: 'asbx-dev-snet-mgmt-01'
  vnetAddressPrefix: '10.10.0.0/16'
  aksSubnetPrefix: '10.10.1.0/24'
  privateEndpointsSubnetPrefix: '10.10.2.0/24'
  applicationGatewaySubnetPrefix: '10.10.3.0/24'
  managementSubnetPrefix: '10.10.4.0/24'
  aksSubnetPrivateEndpointNetworkPolicies: 'Disabled'
  privateEndpointsSubnetPrivateEndpointNetworkPolicies: 'Disabled'
  privateEndpointsSubnetPrivateLinkServiceNetworkPolicies: 'Disabled'
  applicationGatewaySubnetPrivateEndpointNetworkPolicies: 'Disabled'
  aksNsgSecurityRules: []
  privateEndpointsNsgSecurityRules: []
  applicationGatewayNsgSecurityRules: []
  managementNsgSecurityRules: [
    {
      name: 'AllowSshInboundFromTrustedIpToManagementSubnet'
      properties: {
        access: 'Allow'
        description: 'Allow inbound SSH from trusted public IP to management subnet'
        destinationAddressPrefix: '10.10.4.0/24'
        destinationPortRange: '22'
        direction: 'Inbound'
        priority: 130
        protocol: 'Tcp'
        sourceAddressPrefix: '188.90.45.150/32'
        sourcePortRange: '*'
      }
    }
  ]
}

param managedIdentityAksName = 'asbx-dev-mi-aks-01'
param managedIdentityAppName = 'asbx-dev-mi-app-01'
param workloadIdentityFederatedCredentialConfig = {
  enabled: true
  federatedCredentialName: 'asbx-dev-fic-app-workload-01'
  serviceAccountNamespace: 'app-dev'
  serviceAccountName: 'app-workload-sa'
  audiences: [
    'api://AzureADTokenExchange'
  ]
}
param logAnalyticsWorkspaceName = 'asbx-dev-law-01'
param keyVaultName = 'asbx-dev-kv-01'
param diskEncryptionKeyName = 'asbx-dev-key-01'
param diskEncryptionSetName = 'asbx-dev-des-01'
param aksSubnetResourceId = '/subscriptions/02317d41-74ee-434f-8676-d0e761d9ae83/resourceGroups/asbx-dev-rg-01/providers/Microsoft.Network/virtualNetworks/asbx-dev-vnet-01/subnets/asbx-dev-snet-aks-01'
param keyVaultAppIdentityRoleDefinitionId = '/providers/Microsoft.Authorization/roleDefinitions/4633458b-17de-408a-b874-0445c86b69e6'
param monitoringConfig = {
  skuName: 'PerGB2018'
  retentionInDays: 30
  enableLogAccessUsingOnlyResourcePermissions: true
}
param keyVaultConfig = {
  skuFamily: 'A'
  skuName: 'standard'
  enableRbacAuthorization: true
  publicNetworkAccess: 'Enabled'
}

param encryptionConfig = {
  diskEncryptionSetEncryptionType: 'EncryptionAtRestWithCustomerKey'
  keyVaultRbacRoleDefinitionId: '/subscriptions/02317d41-74ee-434f-8676-d0e761d9ae83/providers/Microsoft.Authorization/roleDefinitions/e147488a-f6f5-4113-8e2d-b22465e65bf6'
  keyVaultRbacScopeType: 'resource'
  keyVaultRbacTargetResourceGroupName: 'asbx-dev-rg-01'
  keyVaultRbacRoleAssignmentNameSuffix: 'disk-encryption-key-access'
}

param aksClusterName = 'asbx-dev-aks-01'
param aksDnsPrefix = 'asbx-dev-aks'
param aksRbacClusterAdminPrincipalIds = [
  '5a331049-1bd8-466c-b899-411cd195909d'
  '26ae249f-2b00-416c-9c68-5fade033ec89'
]
param aksConfig = {
  skuName: 'Base'
  skuTier: 'Free'
  kubernetesVersion: '1.35'
  enableRBAC: true
  aadManaged: true
  enableAzureRBAC: true
  oidcIssuerEnabled: true
  enablePrivateCluster: true
  privateDNSZone: 'none'
  enablePrivateClusterPublicFQDN: true
  workloadIdentityEnabled: true
  omsAgentEnabled: true
  enableContainerLogV2: 'true'
  useAADAuth: 'true'
  azureKeyvaultSecretsProviderEnabled: true
  systemNodePoolName: 'systemnp'
  systemNodePoolMode: 'System'
  systemNodePoolVmSize: 'Standard_B4ms'
  systemNodePoolOsType: 'Linux'
  systemNodePoolCount: 1
  systemNodePoolType: 'VirtualMachineScaleSets'
  systemNodePoolEnableEncryptionAtHost: true
  userNodePoolName: 'usernp'
  userNodePoolMode: 'User'
  userNodePoolVmSize: 'Standard_B4ms'
  userNodePoolOsType: 'Linux'
  userNodePoolCount: 1
  userNodePoolType: 'VirtualMachineScaleSets'
  userNodePoolEnableEncryptionAtHost: true
  networkOutboundType: 'loadBalancer'
  networkPlugin: 'azure'
  networkPluginMode: 'overlay'
  networkPolicy: 'calico'
  serviceCidr: '10.236.0.0/16'
  dnsServiceIP: '10.236.0.10'
  podCidr: '10.237.0.0/16'
  rbacScopeResourceType: 'Microsoft.ContainerService/managedClusters'
  roleAssignmentNameSuffix: 'aks-rbac-cluster-admin'
}




