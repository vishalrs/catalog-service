targetScope = 'resourceGroup'

@description('Project name used for resource naming')
param projectName string

@description('Azure region for the AKS cluster')
param location string

@description('Name of the AKS cluster')
param aksClusterName string

@description('DNS prefix used by the AKS cluster')
param aksDnsPrefix string

@description('Resource ID of the user-assigned managed identity for AKS')
param managedIdentityResourceId string

@description('Principal ID of the user-assigned managed identity for AKS')
param managedIdentityPrincipalId string

@description('Tenant ID used for AKS AAD profile')
param tenantId string

@description('Resource ID of the Log Analytics workspace for AKS monitoring')
param logAnalyticsWorkspaceResourceId string

@description('Resource ID of the subnet used by the AKS system node pool')
param aksSubnetResourceId string

@description('Principal IDs that should receive Azure Kubernetes Service RBAC Cluster Admin access')
param aksRbacClusterAdminPrincipalIds array

@description('Role definition ID for AKS RBAC Cluster Admin assignments')
param aksRbacClusterAdminRoleDefinitionId string

@description('Network configuration values externalized for environment-specific parameterization')
param networkConfig object

@description('AKS configuration values externalized for environment-specific parameterization')
param aksConfig object

resource aksCluster 'Microsoft.ContainerService/managedClusters@2026-02-01' = {
  name: aksClusterName
  location: location
  sku: {
    name: aksConfig.skuName
    tier: aksConfig.skuTier
  }
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${managedIdentityResourceId}': {}
    }
  }
  properties: {
    dnsPrefix: aksDnsPrefix
    kubernetesVersion: aksConfig.kubernetesVersion
    enableRBAC: aksConfig.enableRBAC

    aadProfile: {
      managed: aksConfig.aadManaged
      enableAzureRBAC: aksConfig.enableAzureRBAC
      tenantID: tenantId
    }

    oidcIssuerProfile: {
      enabled: aksConfig.oidcIssuerEnabled
    }

    apiServerAccessProfile: {
      enablePrivateCluster: aksConfig.enablePrivateCluster
      privateDNSZone: aksConfig.privateDNSZone
      enablePrivateClusterPublicFQDN: aksConfig.enablePrivateClusterPublicFQDN
    }

    disableLocalAccounts: true
    
    securityProfile: {
      workloadIdentity: {
        enabled: aksConfig.workloadIdentityEnabled
      }
    }

    ingressProfile: {
      gatewayAPI: {
        installation: aksConfig.gatewayApiInstallation
      }
      webAppRouting: {
        enabled: aksConfig.applicationRoutingEnabled
        gatewayAPIImplementations: {
          appRoutingIstio: {
            mode: aksConfig.applicationRoutingIstioEnabled
          }
        }
      }
    }
    addonProfiles: {
      omsagent: {
        enabled: aksConfig.omsAgentEnabled
        config: {
          logAnalyticsWorkspaceResourceID: logAnalyticsWorkspaceResourceId
          enableContainerLogV2: aksConfig.enableContainerLogV2
          useAADAuth: aksConfig.useAADAuth
        }
      }
      azureKeyvaultSecretsProvider: {
        enabled: aksConfig.azureKeyvaultSecretsProviderEnabled
      }
    }
    agentPoolProfiles: [
      {
        name: aksConfig.systemNodePoolName
        mode: aksConfig.systemNodePoolMode
        vmSize: aksConfig.systemNodePoolVmSize
        osType: aksConfig.systemNodePoolOsType
        count: aksConfig.systemNodePoolCount
        type: aksConfig.systemNodePoolType
        vnetSubnetID: aksSubnetResourceId
        enableEncryptionAtHost: aksConfig.systemNodePoolEnableEncryptionAtHost
        nodeLabels: {
          projectName: projectName
          nodepoolType: 'system'
        }
      }
    ]
    networkProfile: {
      outboundType: aksConfig.networkOutboundType
      networkPlugin: aksConfig.networkPlugin
      networkPluginMode: aksConfig.networkPluginMode
      networkPolicy: aksConfig.networkPolicy
      serviceCidr: aksConfig.serviceCidr
      dnsServiceIP: aksConfig.dnsServiceIP
      podCidr: aksConfig.podCidr
    }
  }
}

module aksRbacClusterAdminAssignments '../rbac/role-assignments.bicep' = {
  name: 'aks-rbac-cluster-admin-assignments'
  params: {
    scopeResourceType: aksConfig.rbacScopeResourceType
    scopeResourceName: aksCluster.name
    roleDefinitionId: aksRbacClusterAdminRoleDefinitionId
    principalIds: aksRbacClusterAdminPrincipalIds
    roleAssignmentNameSuffix: aksConfig.roleAssignmentNameSuffix
  }
}

module aksNetworkContributorAssignment '../rbac/role-assignments.bicep' = {
  name: 'aks-network-contributor-assignment'

  params: {
    scopeResourceType: 'Microsoft.Network/virtualNetworks'
    scopeResourceName: networkConfig.vnetName
    roleDefinitionId: aksConfig.networkContributorRoleDefinitionId
    principalIds: [
      managedIdentityPrincipalId
    ]
    roleAssignmentNameSuffix: 'aks-network-contributor'
  }
}

output aksClusterName string = aksCluster.name
output aksClusterId string = aksCluster.id
output oidcIssuerUrl string = aksCluster.properties.oidcIssuerProfile.issuerURL
