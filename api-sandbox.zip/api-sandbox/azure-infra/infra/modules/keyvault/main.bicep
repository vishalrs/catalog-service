targetScope = 'resourceGroup'

@description('Name of the Key Vault')
param keyVaultName string

@description('Azure region for the Key Vault')
param location string

@description('Tenant ID for the Key Vault')
param tenantId string = tenant().tenantId

@description('Configuration values for Key Vault properties')
param keyVaultConfig object

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  properties: {
    tenantId: tenantId
    sku: {
      family: keyVaultConfig.skuFamily
      name: keyVaultConfig.skuName
    }
    enableRbacAuthorization: keyVaultConfig.enableRbacAuthorization
  }
}

output keyVaultName string = keyVault.name
output keyVaultId string = keyVault.id
