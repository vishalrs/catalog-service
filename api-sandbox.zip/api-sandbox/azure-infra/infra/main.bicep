targetScope = 'subscription'

@description('Project name used for the deployment')
param projectName string = 'asbx'

@description('Environment name used for the deployment')
param environmentName string

@description('Azure region for the deployment')
param location string = 'westeurope'

@description('Configuration for the network deployment')
param networkConfig object

@description('Configuration values for Log Analytics workspace')
param monitoringConfig object

@description('Configuration for the managed identity deployment for AKS')
param managedIdentityAks string

@description('Name of the Log Analytics workspace used for AKS monitoring')
param logAnalyticsWorkspaceName string

@description('Name of the Key Vault to create')
param keyVaultName string

@description('Configuration values for Key Vault properties')
param keyVaultConfig object

@description('Name of the Key Vault key used by the Disk Encryption Set')
param diskEncryptionKeyName string

@description('Configuration values for Key Vault key properties')
param keyVaultKeyConfig object

@description('Name of the Disk Encryption Set')
param diskEncryptionSetName string

@description('Key expiry date for created Key Vault keys')
param keyExpiryDate string = dateTimeAdd(utcNow(), 'P180D')

@description('Tenant ID used for AKS AAD profile')
param aksTenantId string = tenant().tenantId

@description('Name of the AKS cluster')
param aksClusterName string

@description('DNS prefix used by the AKS cluster')
param aksDnsPrefix string

@description('Principal IDs that should receive Azure Kubernetes Service RBAC Cluster Admin access')
param aksRbacClusterAdminPrincipalIds array

@description('Role definition ID for AKS RBAC Cluster Admin assignments')
param aksRbacClusterAdminRoleDefinitionId string = '/subscriptions/02317d41-74ee-434f-8676-d0e761d9ae83/providers/Microsoft.Authorization/roleDefinitions/b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b'

@description('AKS configuration values externalized for environment-specific parameterization')
param aksConfig object

@description('Encryption configuration values externalized for environment-specific parameterization')
param encryptionConfig object

var resourceGroupName = networkConfig.resourceGroupName
var aksSubnetResourceId = resourceId(subscription().subscriptionId, resourceGroupName, 'Microsoft.Network/virtualNetworks/subnets', networkConfig.vnetName, networkConfig.aksSubnetName)

resource resourceGroup 'Microsoft.Resources/resourceGroups@2024-03-01' existing = {
  name: resourceGroupName
}

module network './modules/network/main.bicep' = {
  name: 'network-${environmentName}'
  scope: resourceGroup
  params: {
    location: location
    networkConfig: networkConfig
  }
}

module managedIdentity './modules/identity/main.bicep' = {
  name: 'identity-${environmentName}-${managedIdentityAks}'
  scope: resourceGroup
  params: {
    managedIdentityName: managedIdentityAks
    location: location
  }
}

module monitoring './modules/monitoring/main.bicep' = {
  name: 'monitoring-${environmentName}'
  scope: resourceGroup
  params: {
    logAnalyticsWorkspaceName: logAnalyticsWorkspaceName
    location: location
    monitoringConfig: monitoringConfig
  }
}

module keyVault './modules/keyvault/main.bicep' = {
  name: 'keyvault-${environmentName}'
  scope: resourceGroup
  params: {
    keyVaultName: keyVaultName
    location: location
    keyVaultConfig: keyVaultConfig
  }
}

module encryption './modules/encryption/main.bicep' = {
  name: 'encryption-${environmentName}'
  scope: resourceGroup
  params: {
    keyVaultName: keyVaultName
    keyVaultId: keyVault.outputs.keyVaultId
    keyName: diskEncryptionKeyName
    diskEncryptionSetName: diskEncryptionSetName
    location: location
    keyExpiryDate: keyExpiryDate
    keyVaultKeyConfig: keyVaultKeyConfig
    diskEncryptionSetEncryptionType: encryptionConfig.diskEncryptionSetEncryptionType
    keyVaultRbacRoleDefinitionId: encryptionConfig.keyVaultRbacRoleDefinitionId
    keyVaultRbacScopeType: encryptionConfig.keyVaultRbacScopeType
    keyVaultRbacTargetResourceGroupName: encryptionConfig.keyVaultRbacTargetResourceGroupName
    keyVaultRbacRoleAssignmentNameSuffix: encryptionConfig.keyVaultRbacRoleAssignmentNameSuffix
  }
}

module aks './modules/aks/main.bicep' = {
  name: 'aks-${environmentName}'
  scope: resourceGroup
  params: {
    projectName: projectName
    location: location
    aksClusterName: aksClusterName
    aksDnsPrefix: aksDnsPrefix
    managedIdentityResourceId: managedIdentity.outputs.managedIdentityResourceId
    tenantId: aksTenantId
    logAnalyticsWorkspaceResourceId: monitoring.outputs.logAnalyticsWorkspaceId
    aksSubnetResourceId: aksSubnetResourceId
    aksRbacClusterAdminPrincipalIds: aksRbacClusterAdminPrincipalIds
    aksRbacClusterAdminRoleDefinitionId: aksRbacClusterAdminRoleDefinitionId
    aksConfig: aksConfig
  }
}

output subscriptionId string = subscription().subscriptionId
output tenantId string = tenant().tenantId
output projectName string = projectName
output deploymentEnvironment string = environmentName
output resourceGroupName string = resourceGroup.name
output vnetName string = network.outputs.vnetName
output logAnalyticsWorkspaceName string = monitoring.outputs.logAnalyticsWorkspaceName
output logAnalyticsWorkspaceId string = monitoring.outputs.logAnalyticsWorkspaceId
output keyVaultName string = keyVault.outputs.keyVaultName
output keyVaultId string = keyVault.outputs.keyVaultId
output diskEncryptionKeyName string = encryption.outputs.keyName
output diskEncryptionSetName string = encryption.outputs.diskEncryptionSetName
output diskEncryptionSetId string = encryption.outputs.diskEncryptionSetId
output aksClusterName string = aks.outputs.aksClusterName
output aksClusterId string = aks.outputs.aksClusterId
