targetScope = 'resourceGroup'

@description('Azure region for the deployment')
param location string

@description('Configuration for the network deployment')
param networkConfig object

var aksNetworkSecurityGroupName = networkConfig.?aksNetworkSecurityGroupName ?? '${networkConfig.networkSecurityGroupName}-aks'
var privateEndpointsNetworkSecurityGroupName = networkConfig.?privateEndpointsNetworkSecurityGroupName ?? '${networkConfig.networkSecurityGroupName}-pe'
var applicationGatewayNetworkSecurityGroupName = networkConfig.?applicationGatewayNetworkSecurityGroupName ?? '${networkConfig.networkSecurityGroupName}-agw'
var managementNetworkSecurityGroupName = networkConfig.?managementNetworkSecurityGroupName ?? '${networkConfig.networkSecurityGroupName}-mgmt'

var aksNsgSecurityRules = networkConfig.?aksNsgSecurityRules ?? networkConfig.nsgSecurityRules
var privateEndpointsNsgSecurityRules = networkConfig.?privateEndpointsNsgSecurityRules ?? networkConfig.nsgSecurityRules
var applicationGatewayNsgSecurityRules = networkConfig.?applicationGatewayNsgSecurityRules ?? networkConfig.nsgSecurityRules
var managementNsgSecurityRules = networkConfig.?managementNsgSecurityRules ?? networkConfig.nsgSecurityRules

resource aksNetworkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: aksNetworkSecurityGroupName
  location: location
  properties: {
    securityRules: aksNsgSecurityRules
  }
}

resource privateEndpointsNetworkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: privateEndpointsNetworkSecurityGroupName
  location: location
  properties: {
    securityRules: privateEndpointsNsgSecurityRules
  }
}

resource applicationGatewayNetworkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: applicationGatewayNetworkSecurityGroupName
  location: location
  properties: {
    securityRules: applicationGatewayNsgSecurityRules
  }
}

resource managementNetworkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: managementNetworkSecurityGroupName
  location: location
  properties: {
    securityRules: managementNsgSecurityRules
  }
}

resource aksEgressRouteTable 'Microsoft.Network/routeTables@2024-05-01' = {
  name: networkConfig.aksRouteTableName
  location: location
  properties: {
    routes: [
      {
        name: 'default-to-management-vm'
        properties: {
          addressPrefix: '0.0.0.0/0'
          nextHopType: 'VirtualAppliance'
          nextHopIpAddress: networkConfig.aksEgressNextHopIp
        }
      }
    ]
  }
}

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: networkConfig.vnetName
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [
        networkConfig.vnetAddressPrefix
      ]
    }
    subnets: [
      {
        name: networkConfig.aksSubnetName
        properties: {
          addressPrefix: networkConfig.aksSubnetPrefix
          privateEndpointNetworkPolicies: networkConfig.aksSubnetPrivateEndpointNetworkPolicies
          networkSecurityGroup: {
            id: aksNetworkSecurityGroup.id
          }
          routeTable: {
            id: aksEgressRouteTable.id
          }
        }
      }
      {
        name: networkConfig.privateEndpointsSubnetName
        properties: {
          addressPrefix: networkConfig.privateEndpointsSubnetPrefix
          privateEndpointNetworkPolicies: networkConfig.privateEndpointsSubnetPrivateEndpointNetworkPolicies
          privateLinkServiceNetworkPolicies: networkConfig.privateEndpointsSubnetPrivateLinkServiceNetworkPolicies
          networkSecurityGroup: {
            id: privateEndpointsNetworkSecurityGroup.id
          }
        }
      }
      {
        name: networkConfig.applicationGatewaySubnetName
        properties: {
          addressPrefix: networkConfig.applicationGatewaySubnetPrefix
          privateEndpointNetworkPolicies: networkConfig.applicationGatewaySubnetPrivateEndpointNetworkPolicies
          networkSecurityGroup: {
            id: applicationGatewayNetworkSecurityGroup.id
          }
        }
      }
      {
        name: networkConfig.managementSubnetName
        properties: {
          addressPrefix: networkConfig.managementSubnetPrefix
          networkSecurityGroup: {
            id: managementNetworkSecurityGroup.id
          }
        }
      }
    ]
  }
}

output vnetName string = virtualNetwork.name
output aksSubnetName string = networkConfig.aksSubnetName
output privateEndpointsSubnetName string = networkConfig.privateEndpointsSubnetName
output applicationGatewaySubnetName string = networkConfig.applicationGatewaySubnetName
output managementSubnetName string = networkConfig.managementSubnetName
