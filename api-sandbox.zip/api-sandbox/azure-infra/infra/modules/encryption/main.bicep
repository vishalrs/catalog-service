targetScope = 'resourceGroup'

@description('Name of the existing Key Vault')
param keyVaultName string

@description('Resource ID of the existing Key Vault')
param keyVaultId string

@description('Name of the key to create in the Key Vault')
param keyName string

@description('Name of the Disk Encryption Set')
param diskEncryptionSetName string

@description('Key expiry date for created Key Vault keys')
param keyExpiryDate string

@description('Azure region for the Disk Encryption Set')
param location string

@description('Encryption type for the Disk Encryption Set')
param diskEncryptionSetEncryptionType string

@description('Role definition ID used for Key Vault RBAC assignment')
param keyVaultRbacRoleDefinitionId string

@description('Scope type for Key Vault RBAC assignment')
param keyVaultRbacScopeType string

@description('Target resource group name for Key Vault RBAC assignment')
param keyVaultRbacTargetResourceGroupName string

@description('Suffix used to generate Key Vault RBAC role assignment name')
param keyVaultRbacRoleAssignmentNameSuffix string

@description('Configuration values for Key Vault key properties')
param keyVaultKeyConfig object

module keyVaultKey './../keyvault-key/main.bicep' = {
  name: 'keyvault-key-${keyName}'
  params: {
    keyVaultName: keyVaultName
    keyName: keyName
    keyExpiryDate: keyExpiryDate
    keyVaultKeyConfig: keyVaultKeyConfig
  }
}

resource diskEncryptionSet 'Microsoft.Compute/diskEncryptionSets@2024-03-01' = {
  name: diskEncryptionSetName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    encryptionType: diskEncryptionSetEncryptionType
    activeKey: {
      sourceVault: {
        id: keyVaultId
      }
      keyUrl: keyVaultKey.outputs.keyUriWithVersion
    }
  }
}

module keyVaultRbac './../keyvault-rbac/main.bicep' = {
  name: 'keyvault-rbac-${diskEncryptionSetName}'
  params: {
    principalId: diskEncryptionSet.identity.principalId
    roleDefinitionId: keyVaultRbacRoleDefinitionId
    scopeType: keyVaultRbacScopeType
    targetResourceGroupName: keyVaultRbacTargetResourceGroupName
    roleAssignmentNameSuffix: keyVaultRbacRoleAssignmentNameSuffix
  }
}

output keyName string = keyVaultKey.outputs.keyName
output keyUriWithVersion string = keyVaultKey.outputs.keyUriWithVersion
output diskEncryptionSetName string = diskEncryptionSet.name
output diskEncryptionSetId string = diskEncryptionSet.id
output diskEncryptionSetPrincipalId string = diskEncryptionSet.identity.principalId
