targetScope = 'resourceGroup'

@description('Principal ID that should receive the role assignment')
param principalId string

@description('Role definition ID to assign')
param roleDefinitionId string

@description('Name of the target Key Vault resource')
param targetResourceName string

@description('Suffix used to generate a unique role assignment name')
param roleAssignmentNameSuffix string = 'rbac-assignment'

@description('Principal type for the role assignment')
param principalType string = 'ServicePrincipal'

resource targetResource 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: targetResourceName
}

resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(targetResource.id, principalId, roleAssignmentNameSuffix)
  scope: targetResource
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
    principalType: principalType
  }
}

output roleAssignmentId string = roleAssignment.id
