targetScope = 'resourceGroup'

@description('Resource type used as the RBAC assignment scope.')
@allowed([
  'Microsoft.ContainerService/managedClusters'
  'Microsoft.KeyVault/vaults'
  'Microsoft.OperationalInsights/workspaces'
  'Microsoft.Network/virtualNetworks'
])
param scopeResourceType string

@description('Resource name used as the RBAC assignment scope.')
param scopeResourceName string

@description('Role definition ID to assign.')
param roleDefinitionId string

@description('Principal IDs that should receive the role assignment.')
param principalIds array

@description('Optional suffix used to generate deterministic role assignment names.')
param roleAssignmentNameSuffix string

resource aksScope 'Microsoft.ContainerService/managedClusters@2024-05-01' existing = if (scopeResourceType == 'Microsoft.ContainerService/managedClusters') {
  name: scopeResourceName
}

resource keyVaultScope 'Microsoft.KeyVault/vaults@2023-07-01' existing = if (scopeResourceType == 'Microsoft.KeyVault/vaults') {
  name: scopeResourceName
}

resource logAnalyticsScope 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = if (scopeResourceType == 'Microsoft.OperationalInsights/workspaces') {
  name: scopeResourceName
}

resource vnetScope 'Microsoft.Network/virtualNetworks@2024-05-01' existing = if (scopeResourceType == 'Microsoft.Network/virtualNetworks') {
  name: scopeResourceName
}

resource aksRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in principalIds: if (scopeResourceType == 'Microsoft.ContainerService/managedClusters') {
  name: guid(aksScope.id, principalId, roleDefinitionId, roleAssignmentNameSuffix)
  scope: aksScope
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
  }
}]

resource keyVaultRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in principalIds: if (scopeResourceType == 'Microsoft.KeyVault/vaults') {
  name: guid(keyVaultScope.id, principalId, roleDefinitionId, roleAssignmentNameSuffix)
  scope: keyVaultScope
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
  }
}]

resource logAnalyticsRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in principalIds: if (scopeResourceType == 'Microsoft.OperationalInsights/workspaces') {
  name: guid(logAnalyticsScope.id, principalId, roleDefinitionId, roleAssignmentNameSuffix)
  scope: logAnalyticsScope
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
  }
}]

resource vnetRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in principalIds: if (scopeResourceType == 'Microsoft.Network/virtualNetworks') {
  name: guid(vnetScope.id, principalId, roleDefinitionId, roleAssignmentNameSuffix)
  scope: vnetScope
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
  }
}]
