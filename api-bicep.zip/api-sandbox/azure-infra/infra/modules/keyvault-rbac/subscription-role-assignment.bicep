targetScope = 'subscription'

@description('Principal ID that should receive the role assignment')
param principalId string

@description('Role definition ID to assign')
param roleDefinitionId string

@description('Suffix used to generate a unique role assignment name')
param roleAssignmentNameSuffix string = 'rbac-assignment'

@description('Principal type for the role assignment')
param principalType string = 'ServicePrincipal'

resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(subscription().id, principalId, roleAssignmentNameSuffix)
  scope: subscription()
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
    principalType: principalType
  }
}

output roleAssignmentId string = roleAssignment.id
