targetScope = 'resourceGroup'

@description('Name of the user-assigned managed identity that will receive the federated credential')
param managedIdentityName string

@description('Name of the federated credential to create on the managed identity')
param federatedCredentialName string

@description('OIDC issuer URL exposed by the AKS cluster')
param issuerUrl string

@description('Kubernetes namespace for the trusted service account')
param serviceAccountNamespace string

@description('Kubernetes service account name trusted by this credential')
param serviceAccountName string

@description('Audiences allowed for token exchange')
param audiences array = [
  'api://AzureADTokenExchange'
]

resource managedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = {
  name: managedIdentityName
}

resource federatedCredential 'Microsoft.ManagedIdentity/userAssignedIdentities/federatedIdentityCredentials@2023-01-31' = {
  parent: managedIdentity
  name: federatedCredentialName
  properties: {
    issuer: issuerUrl
    subject: 'system:serviceaccount:${serviceAccountNamespace}:${serviceAccountName}'
    audiences: audiences
  }
}

output federatedCredentialId string = federatedCredential.id
output federatedCredentialName string = federatedCredential.name
output subject string = federatedCredential.properties.subject
