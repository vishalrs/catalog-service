# API Sandbox

This repository now includes a starter Azure infrastructure and DevOps structure built with Bicep and Azure Pipelines.

## Structure

- [azure-infra/infra](azure-infra/infra) - Bicep entrypoint, modules, and environment parameter files
- [azure-infra/infra/modules](azure-infra/infra/modules) - reusable Bicep modules for network, app service, and storage
- [azure-infra/infra/environments](azure-infra/infra/environments) - environment-specific parameter files for dev, acc, test, and prod
- [azure-infra/pipelines](azure-infra/pipelines) - Azure Pipelines YAML and reusable stage templates
- [azure-infra/scripts](azure-infra/scripts) - helper scripts for deployment tasks
- [workloads](workloads) - workload deployment assets for pods/apps, including pipeline YAML and scripts
- [azure-infra/docs](azure-infra/docs) - documentation and architecture notes

## Getting started

1. Review and update the placeholder values in [azure-infra/pipelines/azure-pipelines.yml](azure-infra/pipelines/azure-pipelines.yml), including the Azure service connection and deployment settings.
2. Adjust the environment parameter files in [azure-infra/infra/environments](azure-infra/infra/environments) as needed for your subscription and location.
3. Run the deployment helper script from [azure-infra/scripts/deploy.sh](azure-infra/scripts/deploy.sh) or trigger the pipeline in Azure DevOps.

## Next steps

- Replace placeholder values with your real Azure subscription, location, and resource naming conventions.
- Extend the Bicep modules with your actual infrastructure requirements.
- Commit the changes and run the pipeline for your target environment.
