# Azure Infrastructure Documentation

This folder contains the Azure infrastructure and pipeline assets for the project.

## Contents

- infra/: Bicep entrypoint, modules, and environment parameter files
- pipelines/: Azure Pipelines YAML and reusable templates
- scripts/: deployment helpers
- docs/: architecture and deployment notes
