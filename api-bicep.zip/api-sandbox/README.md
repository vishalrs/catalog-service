# API Sandbox

This repository now includes a starter Azure infrastructure and DevOps structure built with Bicep and Azure Pipelines.

## Structure

- [azure-infra/infra](azure-infra/infra) - Bicep entrypoint, modules, and environment parameter files
- [azure-infra/infra/modules](azure-infra/infra/modules) - reusable Bicep modules for network, app service, and storage
- [azure-infra/infra/environments](azure-infra/infra/environments) - environment-specific parameter files for dev, acc, test, and prod
- [azure-infra/pipelines](azure-infra/pipelines) - Azure Pipelines YAML and reusable stage templates
- [azure-infra/scripts](azure-infra/scripts) - helper scripts for deployment tasks
- [workloads](workloads) - workload deployment assets for pods/apps, including pipeline YAML and scripts
- [azure-infra/docs](azure-infra/docs) - documentation and architecture notes

## Getting started

1. Review and update the placeholder values in [azure-infra/pipelines/azure-pipelines.yml](azure-infra/pipelines/azure-pipelines.yml), including the Azure service connection and deployment settings.
2. Adjust the environment parameter files in [azure-infra/infra/environments](azure-infra/infra/environments) as needed for your subscription and location.
3. Run the deployment helper script from [azure-infra/scripts/deploy.sh](azure-infra/scripts/deploy.sh) or trigger the pipeline in Azure DevOps.

## Next steps

- Replace placeholder values with your real Azure subscription, location, and resource naming conventions.
- Extend the Bicep modules with your actual infrastructure requirements.
- Commit the changes and run the pipeline for your target environment.

## Network baseline (dev solution)

Source: [azure-infra/infra/environments/dev/solution.bicepparam](azure-infra/infra/environments/dev/solution.bicepparam)

### VNet and subnets

| Item | Value |
|---|---|
| VNet name | asbx-dev-vnet-01 |
| VNet CIDR | 10.10.0.0/16 |
| AKS subnet | asbx-dev-snet-aks-01 (10.10.1.0/24) |
| Private Endpoints subnet | asbx-dev-snet-pe-01 (10.10.2.0/24) |
| Application Gateway subnet | asbx-dev-snet-agw-01 (10.10.3.0/24) |
| Management subnet | asbx-dev-snet-mgmt-01 (10.10.4.0/24) |
| NSG name | asbx-dev-nsg-01 |

### NSG rules

#### Shared VNet baseline rules

| Priority | Rule name | Direction | Protocol | Source | Source port | Destination | Destination port | Access | Purpose |
|---|---|---|---|---|---|---|---|---|---|
| 100 | AllowVnetInbound | Inbound | * | VirtualNetwork | * | VirtualNetwork | * | Allow | Allow inbound traffic within VNet |
| 110 | AllowVnetOutbound | Outbound | * | VirtualNetwork | * | VirtualNetwork | * | Allow | Allow outbound traffic within VNet |

#### AKS subnet (asbx-dev-snet-aks-01 / 10.10.1.0/24)

| Priority | Rule name | Direction | Protocol | Source | Source port | Destination | Destination port | Access | Purpose |
|---|---|---|---|---|---|---|---|---|---|
| 140 | AllowAzureDevOpsInboundAks | Inbound | Tcp | AzureDevOps | * | 10.10.1.0/24 | 443 | Allow | Allow Azure DevOps HTTPS to AKS subnet |
| 170 | AllowManagementSubnetOutboundToAks443 | Outbound | Tcp | 10.10.4.0/24 | * | 10.10.1.0/24 | 443 | Allow | Allow Management subnet HTTPS to AKS subnet |

#### Private Endpoints subnet (asbx-dev-snet-pe-01 / 10.10.2.0/24)

| Priority | Rule name | Direction | Protocol | Source | Source port | Destination | Destination port | Access | Purpose |
|---|---|---|---|---|---|---|---|---|---|
| 150 | AllowAzureDevOpsInboundPrivateEndpoints | Inbound | Tcp | AzureDevOps | * | 10.10.2.0/24 | 443 | Allow | Allow Azure DevOps HTTPS to Private Endpoints subnet |
| 180 | AllowManagementSubnetOutboundToPle443 | Outbound | Tcp | 10.10.4.0/24 | * | 10.10.2.0/24 | 443 | Allow | Allow Management subnet HTTPS to Private Endpoints subnet |

#### Application Gateway subnet (asbx-dev-snet-agw-01 / 10.10.3.0/24)

| Priority | Rule name | Direction | Protocol | Source | Source port | Destination | Destination port | Access | Purpose |
|---|---|---|---|---|---|---|---|---|---|
| 160 | AllowAzureDevOpsInboundApplicationGateway | Inbound | Tcp | AzureDevOps | * | 10.10.3.0/24 | 443 | Allow | Allow Azure DevOps HTTPS to Application Gateway subnet |
| 190 | AllowManagementSubnetOutboundToAppGw443 | Outbound | Tcp | 10.10.4.0/24 | * | 10.10.3.0/24 | 443 | Allow | Allow Management subnet HTTPS to Application Gateway subnet |

#### Management subnet (asbx-dev-snet-mgmt-01 / 10.10.4.0/24)

| Priority | Rule name | Direction | Protocol | Source | Source port | Destination | Destination port | Access | Purpose |
|---|---|---|---|---|---|---|---|---|---|
| 130 | AllowSshInboundFromTrustedIpToManagementSubnet | Inbound | Tcp | 188.90.45.150/32 | * | 10.10.4.0/24 | 22 | Allow | Allow SSH from trusted public IP to Management subnet |
| 170 | AllowManagementSubnetOutboundToAks443 | Outbound | Tcp | 10.10.4.0/24 | * | 10.10.1.0/24 | 443 | Allow | Allow Management subnet HTTPS to AKS subnet |
| 180 | AllowManagementSubnetOutboundToPle443 | Outbound | Tcp | 10.10.4.0/24 | * | 10.10.2.0/24 | 443 | Allow | Allow Management subnet HTTPS to Private Endpoints subnet |
| 190 | AllowManagementSubnetOutboundToAppGw443 | Outbound | Tcp | 10.10.4.0/24 | * | 10.10.3.0/24 | 443 | Allow | Allow Management subnet HTTPS to Application Gateway subnet |
| 200 | AllowManagementSubnetOutboundToInternet443 | Outbound | Tcp | 10.10.4.0/24 | * | Internet | 443 | Allow | Allow Management subnet HTTPS to Internet |
