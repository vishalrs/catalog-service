# Pipeline environment variables

Pipeline variables can be stored in environment-specific YAML files under the pipelines/environments folder.

## Structure

- pipelines/environments/dev/variables.yml
- pipelines/environments/acc/variables.yml
- pipelines/environments/test/variables.yml
- pipelines/environments/prod/variables.yml

This keeps the values separate from the main pipeline definition and makes it easy to support more environments, such as acceptance, test, and prod.

## How it works

The main pipeline imports the variables template for the selected environment, so you can keep environment-specific settings isolated and reusable.

The pipeline parameter targetEnvironment supports:

- Development
- Acceptance
- Test
- Production
