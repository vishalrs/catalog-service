targetScope = 'subscription'

@description('Project name used for the deployment')
param projectName string = 'asbx'

@description('Environment name used for the deployment')
param environmentName string

@description('Azure region for the deployment')
param location string = 'westeurope'

@description('Configuration for the network deployment')
param networkConfig object

@description('Configuration values for Log Analytics workspace')
param monitoringConfig object

@description('Configuration for the managed identity deployment for AKS')
param managedIdentityAksName string

@description('Configuration for the managed identity deployment for Application Pods')
param managedIdentityAppName string

@description('Name of the Log Analytics workspace used for AKS monitoring')
param logAnalyticsWorkspaceName string

@description('Name of the Key Vault to create')
param keyVaultName string

@description('Configuration values for Key Vault properties')
param keyVaultConfig object

@description('Name of the Key Vault key used by the Disk Encryption Set')
param diskEncryptionKeyName string

@description('Name of the Disk Encryption Set')
param diskEncryptionSetName string

@description('Encryption configuration values externalized for environment-specific parameterization')
param encryptionConfig object

@description('Tenant ID used for AKS AAD profile')
param aksTenantId string = tenant().tenantId

@description('Name of the AKS cluster')
param aksClusterName string

@description('DNS prefix used by the AKS cluster')
param aksDnsPrefix string

@description('Principal IDs that should receive Azure Kubernetes Service RBAC Cluster Admin access')
param aksRbacClusterAdminPrincipalIds array

@description('Role definition ID for AKS RBAC Cluster Admin assignments')
param aksRbacClusterAdminRoleDefinitionId string = '/subscriptions/02317d41-74ee-434f-8676-d0e761d9ae83/providers/Microsoft.Authorization/roleDefinitions/b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b'

@description('AKS configuration values externalized for environment-specific parameterization')
param aksConfig object

@description('Resource ID of the AKS subnet')
param aksSubnetResourceId string

@description('Role definition ID for Key Vault Secret User role assignment')
param keyVaultAppIdentityRoleDefinitionId string

@description('Configuration for creating a federated credential on the application managed identity for AKS workload identity trust')
param workloadIdentityFederatedCredentialConfig object = {
  enabled: false
  federatedCredentialName: ''
  serviceAccountNamespace: ''
  serviceAccountName: ''
  audiences: [
    'api://AzureADTokenExchange'
  ]
}

var resourceGroupName = networkConfig.resourceGroupName
var createAppIdentityFederatedCredential = workloadIdentityFederatedCredentialConfig.enabled && !empty(workloadIdentityFederatedCredentialConfig.federatedCredentialName) && !empty(workloadIdentityFederatedCredentialConfig.serviceAccountNamespace) && !empty(workloadIdentityFederatedCredentialConfig.serviceAccountName)

resource resourceGroup 'Microsoft.Resources/resourceGroups@2024-03-01' existing = {
  name: resourceGroupName
}

module network './modules/network/main.bicep' = {
  name: 'network-${environmentName}'
  scope: resourceGroup
  params: {
    location: location
    networkConfig: networkConfig
  }
}

module aksManagedIdentity './modules/identity/main.bicep' = {
  name: 'identity-${environmentName}-${managedIdentityAksName}'
  scope: resourceGroup
  params: {
    managedIdentityName: managedIdentityAksName
    location: location
  }
}

module appManagedIdentity './modules/identity/main.bicep' = {
  name: 'identity-${environmentName}-${managedIdentityAppName}'
  scope: resourceGroup
  params: {
    managedIdentityName: managedIdentityAppName
    location: location
  }
}

module monitoring './modules/monitoring/main.bicep' = {
  name: 'monitoring-${environmentName}'
  scope: resourceGroup
  params: {
    logAnalyticsWorkspaceName: logAnalyticsWorkspaceName
    location: location
    monitoringConfig: monitoringConfig
  }
}

module keyVault './modules/keyvault/main.bicep' = {
  name: 'keyvault-${environmentName}'
  scope: resourceGroup
  params: {
    keyVaultName: keyVaultName
    location: location
    keyVaultConfig: keyVaultConfig
  }
}

module encryption './modules/encryption/main.bicep' = {
  name: 'encryption-${environmentName}'
  scope: resourceGroup
  params: {
    keyVaultName: keyVaultName
    keyVaultId: keyVault.outputs.keyVaultId
    keyName: diskEncryptionKeyName
    diskEncryptionSetName: diskEncryptionSetName
    location: location
    diskEncryptionSetEncryptionType: encryptionConfig.diskEncryptionSetEncryptionType
    keyVaultRbacRoleDefinitionId: encryptionConfig.keyVaultRbacRoleDefinitionId
    keyVaultRbacScopeType: encryptionConfig.keyVaultRbacScopeType
    keyVaultRbacTargetResourceGroupName: encryptionConfig.keyVaultRbacTargetResourceGroupName
    keyVaultRbacRoleAssignmentNameSuffix: encryptionConfig.keyVaultRbacRoleAssignmentNameSuffix
  }
}

module aks './modules/aks/main.bicep' = {
  name: 'aks-${environmentName}'
  scope: resourceGroup
  params: {
    projectName: projectName
    location: location
    aksClusterName: aksClusterName
    aksDnsPrefix: aksDnsPrefix
    managedIdentityResourceId: aksManagedIdentity.outputs.managedIdentityResourceId
    tenantId: aksTenantId
    logAnalyticsWorkspaceResourceId: monitoring.outputs.logAnalyticsWorkspaceId
    aksSubnetResourceId: aksSubnetResourceId
    aksRbacClusterAdminPrincipalIds: aksRbacClusterAdminPrincipalIds
    aksRbacClusterAdminRoleDefinitionId: aksRbacClusterAdminRoleDefinitionId
    aksConfig: aksConfig
  }
}

module aksAppIdentityRoleAssignment './modules/keyvault-rbac/main.bicep' = {
  name: 'mi-aks-app-identity-role-assignment-${environmentName}'
  scope: resourceGroup
  params: {
    principalId: appManagedIdentity.outputs.managedIdentityPrincipalId
    roleDefinitionId: keyVaultAppIdentityRoleDefinitionId
    scopeType: 'resource'
    targetResourceName: keyVaultName
  }
}

module appIdentityFederatedCredential './modules/federated-credential/main.bicep' = if (createAppIdentityFederatedCredential) {
  name: 'app-identity-federated-credential-${environmentName}'
  scope: resourceGroup
  params: {
    managedIdentityName: appManagedIdentity.outputs.managedIdentityName
    federatedCredentialName: workloadIdentityFederatedCredentialConfig.federatedCredentialName
    issuerUrl: aks.outputs.oidcIssuerUrl
    serviceAccountNamespace: workloadIdentityFederatedCredentialConfig.serviceAccountNamespace
    serviceAccountName: workloadIdentityFederatedCredentialConfig.serviceAccountName
    audiences: workloadIdentityFederatedCredentialConfig.audiences
  }
}
output subscriptionId string = subscription().subscriptionId
output tenantId string = tenant().tenantId
output projectName string = projectName
output deploymentEnvironment string = environmentName
output resourceGroupName string = resourceGroup.name
output vnetName string = network.outputs.vnetName
output aksOidcIssuerUrl string = aks.outputs.oidcIssuerUrl
// output logAnalyticsWorkspaceName string = monitoring.outputs.logAnalyticsWorkspaceName
// output logAnalyticsWorkspaceId string = monitoring.outputs.logAnalyticsWorkspaceId
// output keyVaultName string = keyVault.outputs.keyVaultName
// output keyVaultId string = keyVault.outputs.keyVaultId
// output diskEncryptionKeyName string = encryption.outputs.keyName
// output diskEncryptionSetName string = encryption.outputs.diskEncryptionSetName
// output diskEncryptionSetId string = encryption.outputs.diskEncryptionSetId
// output aksClusterName string = aks.outputs.aksClusterName
// output aksClusterId string = aks.outputs.aksClusterId
