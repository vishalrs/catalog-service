# Workload Deployment

Use this folder for Kubernetes workload deployment assets (pods, apps, services, and related rollout automation).

## Structure

- `pipelines/`: CI/CD pipeline YAML files for workload deployments.
- `scripts/`: Shell scripts used by those pipelines (kubectl/helm wrappers, validation, rollout checks).

## Suggested naming

- Pipelines: `deploy-<app>-<env>.yml`
- Scripts: `deploy-<app>.sh`, `validate-<app>.sh`, `rollback-<app>.sh`
