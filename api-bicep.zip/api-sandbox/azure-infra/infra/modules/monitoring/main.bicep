targetScope = 'resourceGroup'

@description('Name of the Log Analytics workspace')
param logAnalyticsWorkspaceName string

@description('Azure region for the workspace')
param location string

@description('Configuration values for Log Analytics workspace')
param monitoringConfig object

resource logAnalyticsWorkspace 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: logAnalyticsWorkspaceName
  location: location
  properties: {
    sku: {
      name: monitoringConfig.skuName
    }
    retentionInDays: monitoringConfig.retentionInDays
    features: {
      enableLogAccessUsingOnlyResourcePermissions: monitoringConfig.enableLogAccessUsingOnlyResourcePermissions
    }
  }
}

output logAnalyticsWorkspaceName string = logAnalyticsWorkspace.name
output logAnalyticsWorkspaceId string = logAnalyticsWorkspace.id
