using '../../main.bicep'

param environmentName = 'acc'
param networkConfig = {
  resourceGroupName: 'asbx-acc-rg-01'
  vnetName: 'asbx-acc-vnet-01'
  networkSecurityGroupName: 'asbx-acc-nsg-01'
  aksSubnetName: 'asbx-acc-snet-shared-01'
  privateEndpointsSubnetName: 'asbx-acc-snet-pe-01'
  applicationGatewaySubnetName: 'asbx-acc-snet-agw-01'
  vnetAddressPrefix: '10.40.0.0/16'
  aksSubnetPrefix: '10.40.1.0/24'
  privateEndpointsSubnetPrefix: '10.40.2.0/24'
  applicationGatewaySubnetPrefix: '10.40.3.0/24'
  aksSubnetPrivateEndpointNetworkPolicies: 'Disabled'
  privateEndpointsSubnetPrivateEndpointNetworkPolicies: 'Disabled'
  privateEndpointsSubnetPrivateLinkServiceNetworkPolicies: 'Disabled'
  applicationGatewaySubnetPrivateEndpointNetworkPolicies: 'Disabled'
  nsgSecurityRules: [
    {
      name: 'AllowVnetInbound'
      properties: {
        access: 'Allow'
        description: 'Allow inbound traffic between all subnets in the virtual network'
        destinationAddressPrefix: 'VirtualNetwork'
        destinationPortRange: '*'
        direction: 'Inbound'
        priority: 100
        protocol: '*'
        sourceAddressPrefix: 'VirtualNetwork'
        sourcePortRange: '*'
      }
    }
    {
      name: 'AllowVnetOutbound'
      properties: {
        access: 'Allow'
        description: 'Allow outbound traffic between all subnets in the virtual network'
        destinationAddressPrefix: 'VirtualNetwork'
        destinationPortRange: '*'
        direction: 'Outbound'
        priority: 110
        protocol: '*'
        sourceAddressPrefix: 'VirtualNetwork'
        sourcePortRange: '*'
      }
    }
    {
      name: 'AllowAzureDevOpsInboundAks'
      properties: {
        access: 'Allow'
        description: 'Allow inbound HTTPS traffic from Azure DevOps to the shared services subnet'
        destinationAddressPrefix: '10.40.1.0/24'
        destinationPortRange: '443'
        direction: 'Inbound'
        priority: 140
        protocol: 'Tcp'
        sourceAddressPrefix: 'AzureDevOps'
        sourcePortRange: '*'
      }
    }
    {
      name: 'AllowAzureDevOpsInboundPrivateEndpoints'
      properties: {
        access: 'Allow'
        description: 'Allow inbound HTTPS traffic from Azure DevOps to the private endpoints subnet'
        destinationAddressPrefix: '10.40.2.0/24'
        destinationPortRange: '443'
        direction: 'Inbound'
        priority: 150
        protocol: 'Tcp'
        sourceAddressPrefix: 'AzureDevOps'
        sourcePortRange: '*'
      }
    }
    {
      name: 'AllowAzureDevOpsInboundApplicationGateway'
      properties: {
        access: 'Allow'
        description: 'Allow inbound HTTPS traffic from Azure DevOps to the application gateway subnet'
        destinationAddressPrefix: '10.40.3.0/24'
        destinationPortRange: '443'
        direction: 'Inbound'
        priority: 160
        protocol: 'Tcp'
        sourceAddressPrefix: 'AzureDevOps'
        sourcePortRange: '*'
      }
    }
  ]
}

param managedIdentityAks = 'asbx-acc-mi-aks-01'
param monitoringConfig = {
  skuName: 'PerGB2018'
  retentionInDays: 30
  enableLogAccessUsingOnlyResourcePermissions: true
}
param keyVaultConfig = {
  skuFamily: 'A'
  skuName: 'standard'
  enableRbacAuthorization: true
}
param keyVaultKeyConfig = {
  kty: 'RSA'
  keySize: 2048
  keyOps: [
    'encrypt'
    'decrypt'
    'wrapKey'
    'unwrapKey'
    'sign'
    'verify'
  ]
  enabled: true
}
param aksClusterName = 'asbx-acc-aks-01'
param aksDnsPrefix = 'asbx-acc-aks'
param aksRbacClusterAdminPrincipalIds = [
  '5a331049-1bd8-466c-b899-411cd195909d'
  '26ae249f-2b00-416c-9c68-5fade033ec89'
]
param aksConfig = {
  skuName: 'Base'
  skuTier: 'Free'
  kubernetesVersion: '1.35'
  enableRBAC: true
  aadManaged: true
  enableAzureRBAC: true
  oidcIssuerEnabled: true
  enablePrivateCluster: true
  privateDNSZone: 'none'
  enablePrivateClusterPublicFQDN: true
  workloadIdentityEnabled: true
  omsAgentEnabled: true
  enableContainerLogV2: 'true'
  useAADAuth: 'true'
  azureKeyvaultSecretsProviderEnabled: true
  systemNodePoolName: 'systemnp'
  systemNodePoolMode: 'System'
  systemNodePoolVmSize: 'Standard_D4s_v5'
  systemNodePoolOsType: 'Linux'
  systemNodePoolCount: 1
  systemNodePoolType: 'VirtualMachineScaleSets'
  systemNodePoolEnableEncryptionAtHost: true
  networkOutboundType: 'userDefinedRouting'
  networkPlugin: 'azure'
  networkPluginMode: 'overlay'
  networkPolicy: 'calico'
  serviceCidr: '10.236.0.0/16'
  dnsServiceIP: '10.236.0.10'
  podCidr: '10.237.0.0/16'
  rbacScopeResourceType: 'Microsoft.ContainerService/managedClusters'
  roleAssignmentNameSuffix: 'aks-rbac-cluster-admin'
}
param encryptionConfig = {
  diskEncryptionSetEncryptionType: 'EncryptionAtRestWithCustomerKey'
  keyVaultRbacRoleDefinitionId: '/subscriptions/02317d41-74ee-434f-8676-d0e761d9ae83/providers/Microsoft.Authorization/roleDefinitions/e147488a-f6f5-4113-8e2d-b22465e1f4fe'
  keyVaultRbacScopeType: 'resourceGroup'
  keyVaultRbacTargetResourceGroupName: 'asbx-acc-rg-01'
  keyVaultRbacRoleAssignmentNameSuffix: 'disk-encryption-key-access'
}
param logAnalyticsWorkspaceName = 'asbx-acc-law-01'
param keyVaultName = 'asbx-acc-kv-01'
param diskEncryptionKeyName = 'asbx-acc-kek-01'
param diskEncryptionSetName = 'asbx-acc-des-01'
