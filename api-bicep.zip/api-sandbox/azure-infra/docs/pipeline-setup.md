# Simple subscription details pipeline

This pipeline uses a single Azure CLI step to:

- authenticate with the Azure service connection defined as a pipeline variable
- use the subscription ID defined as a pipeline variable
- switch to that subscription and print the active account details

## Required pipeline variables

Set these values in your Azure DevOps pipeline variables or in the YAML file before running:

- azureServiceConnection: the name of the Azure service connection
- subscriptionId: the Azure subscription ID to inspect

## Environment selection

When running the main pipeline, set the parameter targetEnvironment to one of:

- Development
- Acceptance
- Test
- Production
