targetScope = 'resourceGroup'

@description('Principal ID that should receive the role assignment')
param principalId string

@description('Role definition ID to assign')
param roleDefinitionId string

@description('Scope type for the role assignment')
@allowed([
  'resourceGroup'
  'subscription'
])
param scopeType string = 'resourceGroup'

@description('Target resource group name when assigning at resource group scope')
param targetResourceGroupName string = resourceGroup().name

@description('Suffix used to generate a unique role assignment name')
param roleAssignmentNameSuffix string = 'rbac-assignment'

@description('Principal type for the role assignment')
param principalType string = 'ServicePrincipal'

module subscriptionRoleAssignment './subscription-role-assignment.bicep' = if (scopeType == 'subscription') {
  name: 'subscription-role-assignment-${roleAssignmentNameSuffix}'
  scope: subscription()
  params: {
    principalId: principalId
    roleDefinitionId: roleDefinitionId
    roleAssignmentNameSuffix: roleAssignmentNameSuffix
    principalType: principalType
  }
}

module resourceGroupRoleAssignment './resource-group-role-assignment.bicep' = if (scopeType == 'resourceGroup') {
  name: 'resource-group-role-assignment-${roleAssignmentNameSuffix}'
  scope: resourceGroup(targetResourceGroupName)
  params: {
    principalId: principalId
    roleDefinitionId: roleDefinitionId
    roleAssignmentNameSuffix: roleAssignmentNameSuffix
    principalType: principalType
  }
}

output roleAssignmentId string = scopeType == 'subscription'
  ? subscriptionRoleAssignment!.outputs.roleAssignmentId
  : resourceGroupRoleAssignment!.outputs.roleAssignmentId
