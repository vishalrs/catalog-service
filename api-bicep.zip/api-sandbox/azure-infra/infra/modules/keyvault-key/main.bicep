targetScope = 'resourceGroup'

@description('Name of the existing Key Vault')
param keyVaultName string

@description('Name of the key to create in the Key Vault')
param keyName string

@description('Expiry date for the created Key Vault key')
param keyExpiryDate string

@description('Configuration values for Key Vault key properties')
param keyVaultKeyConfig object

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyVaultName
}

resource keyVaultKey 'Microsoft.KeyVault/vaults/keys@2023-07-01' = {
  parent: keyVault
  name: keyName
  properties: {
    kty: keyVaultKeyConfig.kty
    keySize: keyVaultKeyConfig.keySize
    keyOps: keyVaultKeyConfig.keyOps
    attributes: {
      enabled: keyVaultKeyConfig.enabled
      exp: dateTimeToEpoch(keyExpiryDate)
    }
  }
}

output keyName string = keyVaultKey.name
output keyUriWithVersion string = keyVaultKey.properties.keyUriWithVersion
