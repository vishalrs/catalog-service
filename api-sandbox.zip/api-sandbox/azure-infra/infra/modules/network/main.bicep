targetScope = 'resourceGroup'

@description('Azure region for the deployment')
param location string

@description('Configuration for the network deployment')
param networkConfig object

resource networkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: networkConfig.networkSecurityGroupName
  location: location
  properties: {
    securityRules: networkConfig.nsgSecurityRules
  }
}

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: networkConfig.vnetName
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [
        networkConfig.vnetAddressPrefix
      ]
    }
    subnets: [
      {
        name: networkConfig.aksSubnetName
        properties: {
          addressPrefix: networkConfig.aksSubnetPrefix
          privateEndpointNetworkPolicies: networkConfig.aksSubnetPrivateEndpointNetworkPolicies
          networkSecurityGroup: {
            id: networkSecurityGroup.id
          }
        }
      }
      {
        name: networkConfig.privateEndpointsSubnetName
        properties: {
          addressPrefix: networkConfig.privateEndpointsSubnetPrefix
          privateEndpointNetworkPolicies: networkConfig.privateEndpointsSubnetPrivateEndpointNetworkPolicies
          privateLinkServiceNetworkPolicies: networkConfig.privateEndpointsSubnetPrivateLinkServiceNetworkPolicies
          networkSecurityGroup: {
            id: networkSecurityGroup.id
          }
        }
      }
      {
        name: networkConfig.applicationGatewaySubnetName
        properties: {
          addressPrefix: networkConfig.applicationGatewaySubnetPrefix
          privateEndpointNetworkPolicies: networkConfig.applicationGatewaySubnetPrivateEndpointNetworkPolicies
          networkSecurityGroup: {
            id: networkSecurityGroup.id
          }
        }
      }
    ]
  }
}

output vnetName string = virtualNetwork.name
output aksSubnetName string = networkConfig.aksSubnetName
output privateEndpointsSubnetName string = networkConfig.privateEndpointsSubnetName
output applicationGatewaySubnetName string = networkConfig.applicationGatewaySubnetName
