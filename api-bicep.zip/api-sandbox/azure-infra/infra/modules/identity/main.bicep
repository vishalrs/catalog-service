targetScope = 'resourceGroup'

@description('Name of the user-assigned managed identity to create')
param managedIdentityName string

@description('Azure region for the managed identity')
param location string

resource managedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: managedIdentityName
  location: location
}

output managedIdentityName string = managedIdentity.name
output managedIdentityResourceId string = managedIdentity.id
output managedIdentityPrincipalId string = managedIdentity.properties.principalId
output managedIdentityClientId string = managedIdentity.properties.clientId
